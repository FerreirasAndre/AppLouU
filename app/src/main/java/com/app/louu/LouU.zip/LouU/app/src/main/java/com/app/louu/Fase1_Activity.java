package com.app.louu;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Fase1_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fase1);
    }
}