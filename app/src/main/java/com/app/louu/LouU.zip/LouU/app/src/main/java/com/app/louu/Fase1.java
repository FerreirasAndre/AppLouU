package com.app.louu;

public class Fase1 extends InitApp {
   public String fase1() {
      String fase1 = "Fase-1";

      String teste = LeJson(fase1);

//     Log.d("Fase1", fase1);
      return teste;

   }
}
