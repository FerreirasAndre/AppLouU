package com.app.louu;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

abstract public class InitApp {
    private ArrayList<String> palavras = new ArrayList();
    private String strPalavras;
    public ArrayList<String> getPalavras() {
        return palavras;
    }
    public void setPalavras(ArrayList<String> palavras) {
        this.palavras = palavras;
    }

    public String getStrPalavras() {
        return strPalavras;
    }

    public void setStrPalavras(String strPalavras) {
        this.strPalavras = strPalavras;
    }

    //Faz a leitura do arquivo Json e trata exceções
    public String LeJson(String fase) {
        JSONObject jSONObject;
        JSONParser parser = new JSONParser();

        try {
            jSONObject = (JSONObject) parser.parse(new FileReader("palavras.json"));

            setStrPalavras(jSONObject.get(fase).toString());

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (org.json.simple.parser.ParseException ex) {
            Logger.getLogger(MainActivity.class.getName()).log(Level.SEVERE, null, ex);
        }
        return getStrPalavras();
    }



}
