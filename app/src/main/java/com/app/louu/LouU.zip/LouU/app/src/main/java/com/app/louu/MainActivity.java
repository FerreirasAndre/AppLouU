package com.app.louu;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

       @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void StartGame (View v){
        //Cria uma nova intent (Intenção!!!) para iniciar a activity (Tela) Fase1_Activity
        Intent Start = new Intent(this, Fase1_Activity.class);
        startActivity(Start);
        Log.d("nova fase", "nova fase");

//        Fase1 primeiraFase = new Fase1();
//        String teste = primeiraFase.fase1();

//       System.out.println(teste);
    }

    public void teste(){

        //Testes de log para debugar
        Fase1 primeiraFase = new Fase1();
        primeiraFase.fase1();
        Log.d("1ª fase", "fase1");
    }
}